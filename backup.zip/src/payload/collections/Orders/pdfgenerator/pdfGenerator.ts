import htmlPdf from 'html-pdf-node';

export const generateOrderPDF = async (order: any): Promise<Buffer> => {
  const invoiceHTML = generateInvoiceHTML(order);
  const file = { content: invoiceHTML };
  const options = { format: 'A4' };

  return new Promise((resolve, reject) => {
    htmlPdf.generatePdf(file, options).then(pdfBuffer => {
      resolve(pdfBuffer);
    }).catch(error => {
      reject(error);
    });
  });
};


const generateInvoiceHTML = (order: any): string => {
  return `
<!DOCTYPE html>
<html lang="en, id">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>A Simple Invoice Template Responsive and clean with HTML CSS SCSS</title>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
      /* Insert the CSS code provided here */
    </style>
  </head>
  <body>
    <section class="wrapper-invoice">
      <div class="invoice">
        <div class="invoice-information">
          <p><b>Invoice #</b> : ${order.id}</p>
          <p><b>Created Date </b>: ${new Date(order.createdAt).toLocaleDateString()}</p>
          <p><b>Due Date</b> : ${new Date(order.createdAt).toLocaleDateString()}</p>
        </div>
        <div class="invoice-logo-brand">
          <img src="your-logo-url.png" alt="Your Logo" />
        </div>
        <div class="invoice-head">
          <div class="head client-info">
            <p>Your Company Name, Inc.</p>
            <p>Company GSTN: Your GST Number</p>
            <p>Your Company Address</p>
            <p>City, State, ZIP</p>
          </div>
          <div class="head client-data">
            <p>-</p>
            <p>${order.orderedBy.name}</p>
            <p>${order.orderedBy.address}</p>
            <p>${order.orderedBy.city}, ${order.orderedBy.state}, ${order.orderedBy.zip}</p>
          </div>
        </div>
        <div class="invoice-body">
          <table class="table">
            <thead>
              <tr>
                <th>Item Description</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              ${order.items.map(item => `
                <tr>
                  <td>${item.title} (${item.size})</td>
                  <td>${(item.price / 100).toFixed(2)}</td>
                </tr>
              `).join('')}
              <tr>
                <td>Tax</td>
                <td>${(order.totalTax / 100).toFixed(2)}</td>
              </tr>
            </tbody>
          </table>
          <div class="flex-table">
            <div class="flex-column"></div>
            <div class="flex-column">
              <table class="table-subtotal">
                <tbody>
                  <tr>
                    <td>Subtotal</td>
                    <td>${(order.total / 100).toFixed(2)}</td>
                  </tr>
                  <tr>
                    <td>Tax</td>
                    <td>${(order.totalTax / 100).toFixed(2)}</td>
                  </tr>
                  <tr>
                    <td>Credit</td>
                    <td>0.00</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="invoice-total-amount">
            <p>Total : ${(order.total / 100).toFixed(2)}</p>
          </div>
        </div>
        <div class="invoice-footer">
          <p>Thank you, happy shopping again</p>
        </div>
      </div>
    </section>
    <div class="copyright">
      <p>Created by ❤ Your Company Name</p>
    </div>
  </body>
</html>
  `;
};
