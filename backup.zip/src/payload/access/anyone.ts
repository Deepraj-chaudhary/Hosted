import type { Access } from 'payload/config'

export const anyone: Access = () => true
